# A. K. M. Nuruzzaman Laskar — Academic Website

Personal academic website hosted at https://akmnuruzzaman.github.io, inspired by the clean layout of Muhammad Ashiq’s academic site (not a copy of its source code).

## Publish

1. Open https://github.com/AKMNURUZZAMAN/akmnuruzzaman.github.io
2. Choose **Add file → Upload files**.
3. Upload the **contents of this folder** (not the enclosing folder). Ensure `index.html` is in the repository root, `assets/style.css` remains in `assets/`, and the PDF stays in `files/`.
4. Commit the changes.
5. Go to **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, `main`, `/(root)`, then **Save**.
6. Visit https://akmnuruzzaman.github.io after publication completes.

## Missing assets / to-do

- **Portrait:** Replace the `.portrait-placeholder` block in `index.html` with `<img src="assets/portrait.jpg" alt="Portrait of A. K. M. Nuruzzaman Laskar">`, add `assets/portrait.jpg`, and style it as needed.
- **Original research figures:** Replace each `.figure-placeholder` block with an `<img>` referencing a figure file placed in `assets/`. Only use figures you have permission to publish.
- **Research PDFs:** DOI links are provided for the four IEEE conference papers. Local PDFs and code links are intentionally omitted until supplied and rights/URLs confirmed.
- **Profile links:** The Google Scholar, ORCID, ResearchGate and LinkedIn links are user-supplied; check each before publishing.
- **CV privacy:** The CV includes a personal phone number, email and referee contact details. Consider creating a public-safe CV without private phone/referee details before publishing.
- **Accuracy:** Review dates, author lists, and metrics against your original CV and papers. Some citations in the CV use “et al.” and ellipses; these are retained rather than inventing missing authors.

## Files

- `index.html` — homepage
- `assets/style.css` — responsive styling
- `files/Nuruzzaman_Laskar_Academic_CV.pdf` — unchanged uploaded CV
- `README.md` — these instructions
